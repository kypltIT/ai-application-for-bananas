<?php $__env->startSection('title', 'Fashion Trend Analysis Results'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Fashion Trend Analysis Results</h1>
                    <a href="<?php echo e(route('admin.trend-analysis.index')); ?>"
                        class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back to Analysis
                    </a>
                </div>

                <?php if(isset($analysis) && $analysis['success']): ?>
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">AI Market Analysis</h6>
                                    <div class="dropdown no-arrow">
                                        <span class="text-xs text-gray-500">Powered by
                                            <?php echo e($analysis['model'] ?? 'AI'); ?></span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="ai-analysis-content">
                                        <?php if(isset($analysis['formatted_content'])): ?>
                                            <?php echo $analysis['formatted_content']; ?>

                                        <?php else: ?>
                                            <?php echo nl2br(e($analysis['analysis'])); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-xl-8 col-lg-7">
                        <div class="card shadow">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Revenue Trend and Forecast</h6>
                            </div>
                            <div class="card-body">
                                <div class="chart-area">
                                    <canvas id="revenueChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-5">
                        <div class="card shadow">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Category Performance</h6>
                            </div>
                            <div class="card-body">
                                <div class="chart-pie pt-4">
                                    <canvas id="categoryPieChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-xl-6 col-lg-6">
                        <div class="card shadow">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Regional Performance</h6>
                            </div>
                            <div class="card-body">
                                <div class="chart-bar">
                                    <canvas id="regionBarChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6">
                        <div class="card shadow">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Recommendations Summary</h6>
                            </div>
                            <div class="card-body">
                                <?php if(isset($analysis) && $analysis['success']): ?>
                                    <div class="recommendations-list">
                                        <div id="recommendations-content">
                                            <p class="text-center text-gray-500">Processing recommendations...</p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p class="text-center text-danger">Unable to generate recommendations. Please try again.
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card shadow">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Detailed Category Data</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Category</th>
                                                <th>Products</th>
                                                <th>Units Sold</th>
                                                <th>Revenue</th>
                                                <th>Growth Potential</th>
                                                <th>Trend Impact</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categoryPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($category->name); ?></td>
                                                    <td><?php echo e($category->product_count); ?></td>
                                                    <td><?php echo e($category->units_sold); ?></td>
                                                    <td>$<?php echo e(number_format($category->revenue, 2)); ?></td>
                                                    <td id="growth-<?php echo e($category->id); ?>">Analyzing...</td>
                                                    <td id="impact-<?php echo e($category->id); ?>">Analyzing...</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Use pre-extracted chart data from controller
            const chartData = <?php echo json_encode(isset($analysis) && isset($analysis['chart_data']) ? $analysis['chart_data'] : null, 15, 512) ?>;
            const salesData = <?php echo json_encode($monthlySales, 15, 512) ?>;
            const categoryData = <?php echo json_encode($categoryPerformance, 15, 512) ?>;
            const regionData = <?php echo json_encode($revenueByRegion, 15, 512) ?>;

            // Use chart data directly without parsing from analysis text
            const aiData = chartData;

            // Skip recommendation extraction from text since it's already in formatted HTML
            if (aiData && aiData.category_impact) {
                categoryData.forEach(category => {
                    const categoryName = category.name.toLowerCase();
                    const categoryImpact = aiData.category_impact.find(c => c.category.toLowerCase() ===
                        categoryName);

                    if (categoryImpact) {
                        const growthElement = document.getElementById(`growth-${category.id}`);
                        const impactElement = document.getElementById(`impact-${category.id}`);

                        if (growthElement) {
                            const growthText = categoryImpact.growth_percentage > 0 ?
                                `+${categoryImpact.growth_percentage}%` :
                                `${categoryImpact.growth_percentage}%`;
                            growthElement.textContent = growthText;

                            if (categoryImpact.growth_percentage > 0) {
                                growthElement.classList.add('text-success');
                            } else if (categoryImpact.growth_percentage < 0) {
                                growthElement.classList.add('text-danger');
                            } else {
                                growthElement.classList.add('text-warning');
                            }
                        }

                        if (impactElement) {
                            impactElement.textContent = categoryImpact.impact.charAt(0).toUpperCase() +
                                categoryImpact.impact.slice(1);

                            if (categoryImpact.impact === 'positive') {
                                impactElement.classList.add('text-success');
                            } else if (categoryImpact.impact === 'negative') {
                                impactElement.classList.add('text-danger');
                            } else {
                                impactElement.classList.add('text-warning');
                            }
                        }
                    }
                });
            }

            let forecastMonths = [];
            if (aiData && aiData.forecast && aiData.forecast.length > 0) {
                forecastMonths = aiData.forecast.map(item => ({
                    month: item.month + ' (Forecast)',
                    revenue: item.revenue,
                    isForecasted: true
                }));
            } else {
                const lastDate = new Date(salesData[salesData.length - 1].date);
                for (let i = 1; i <= 6; i++) {
                    const forecastDate = new Date(lastDate);
                    forecastDate.setMonth(lastDate.getMonth() + i);
                    const month = forecastDate.toLocaleString('default', {
                        month: 'long'
                    });
                    const year = forecastDate.getFullYear();
                    const lastThreeMonths = salesData.slice(-3);
                    const avgRevenue = lastThreeMonths.reduce((sum, item) => sum + item.revenue, 0) /
                        lastThreeMonths.length;

                    forecastMonths.push({
                        month: `${month} ${year} (Forecast)`,
                        revenue: avgRevenue,
                        isForecasted: true
                    });
                }
            }

            const combinedData = [...salesData, ...forecastMonths];

            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            const revenueChart = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: combinedData.map(item => item.month),
                    datasets: [{
                        label: 'Monthly Revenue',
                        data: combinedData.map(item => item.revenue),
                        backgroundColor: combinedData.map(item => item.isForecasted ?
                            'rgba(255, 205, 86, 0.05)' : 'rgba(78, 115, 223, 0.05)'),
                        borderColor: combinedData.map(item => item.isForecasted ?
                            'rgba(255, 205, 86, 1)' : 'rgba(78, 115, 223, 1)'),
                        pointBackgroundColor: combinedData.map(item => item.isForecasted ?
                            'rgba(255, 205, 86, 1)' : 'rgba(78, 115, 223, 1)'),
                        pointBorderColor: '#fff',
                        pointStyle: combinedData.map(item => item.isForecasted ? 'triangle' :
                            'circle'),
                        pointRadius: combinedData.map(item => item.isForecasted ? 5 : 3),
                        borderWidth: 2,
                        fill: true,
                        segment: {
                            borderDash: ctx => ctx.p0.parsed.x >= salesData.length - 1 ? [6, 6] :
                                undefined,
                        }
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value.toLocaleString();
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.dataset.label || '';
                                    const isForecast = context.dataIndex >= salesData.length;
                                    return `${label}${isForecast ? ' (Forecast)' : ''}: $${context.parsed.y.toLocaleString()}`;
                                }
                            }
                        },
                        legend: {
                            display: false
                        }
                    }
                }
            });

            const categoryColors = [];
            const categoryHoverColors = [];

            categoryData.forEach(category => {
                let baseColor = '#4e73df';
                let hoverColor = '#2e59d9';

                if (aiData && aiData.category_impact) {
                    const impact = aiData.category_impact.find(c => c.category.toLowerCase() === category
                        .name.toLowerCase());

                    if (impact) {
                        if (impact.impact === 'positive') {
                            baseColor = '#1cc88a';
                            hoverColor = '#17a673';
                        } else if (impact.impact === 'negative') {
                            baseColor = '#e74a3b';
                            hoverColor = '#e02d1b';
                        } else if (impact.impact === 'neutral') {
                            baseColor = '#f6c23e';
                            hoverColor = '#f4b619';
                        }
                    }
                }

                categoryColors.push(baseColor);
                categoryHoverColors.push(hoverColor);
            });

            const categoryCtx = document.getElementById('categoryPieChart').getContext('2d');
            const categoryPieChart = new Chart(categoryCtx, {
                type: 'doughnut',
                data: {
                    labels: categoryData.map(item => item.name),
                    datasets: [{
                        data: categoryData.map(item => item.revenue),
                        backgroundColor: categoryColors,
                        hoverBackgroundColor: categoryHoverColors,
                        hoverBorderColor: "rgba(234, 236, 244, 1)",
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.parsed || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: $${value.toLocaleString()} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });

            let recommendedRegions = [];
            if (aiData && aiData.recommended_regions) {
                recommendedRegions = aiData.recommended_regions.map(r => r.toLowerCase());
            }

            const regionBackgroundColors = regionData.slice(0, 5).map(item => {
                return recommendedRegions.includes(item.region.toLowerCase()) ? '#1cc88a' : '#4e73df';
            });

            const regionHoverColors = regionData.slice(0, 5).map(item => {
                return recommendedRegions.includes(item.region.toLowerCase()) ? '#17a673' : '#2e59d9';
            });

            const regionCtx = document.getElementById('regionBarChart').getContext('2d');
            const regionBarChart = new Chart(regionCtx, {
                type: 'bar',
                data: {
                    labels: regionData.slice(0, 5).map(item => item.region),
                    datasets: [{
                        label: 'Regional Revenue',
                        data: regionData.slice(0, 5).map(item => item.revenue),
                        backgroundColor: regionBackgroundColors,
                        hoverBackgroundColor: regionHoverColors,
                        borderWidth: 0
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value.toLocaleString();
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = `Revenue: $${context.parsed.y.toLocaleString()}`;
                                    if (recommendedRegions.includes(context.label.toLowerCase())) {
                                        label += ' (Recommended)';
                                    }
                                    return label;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/trend-analysis/result.blade.php ENDPATH**/ ?>