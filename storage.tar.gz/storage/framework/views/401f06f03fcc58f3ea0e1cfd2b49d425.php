<?php $__env->startSection('title', 'Customer List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.customers.index')); ?>">Customer Management
                                </a>
                            </li>
                            <li class="breadcrumb-item"><i class="feather-chevron-right"></i></li>
                            <li class="breadcrumb-item active">Customer List</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="card card-table show-entire">
                        <div class="card-body">

                            <!-- Table Header -->
                            <div class="page-table-header mb-2">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="doctor-table-blk">
                                            <h3>Customer List</h3>
                                            <div class="doctor-search-blk">
                                                <div class="top-nav-search table-search-blk">
                                                    <form>
                                                        <input type="text" class="form-control"
                                                            placeholder="Search here">
                                                        <a class="btn"><img
                                                                src="<?php echo e(asset('assets/admin/img/icons/search-normal.svg')); ?>"
                                                                alt=""></a>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto text-end float-end ms-auto download-grp">
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-01.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-02.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-03.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-04.svg')); ?>"
                                                alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /Table Header -->

                            <div class="table-responsive">
                                <table class="table border-0 custom-table comman-table datatable mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th>Customer Name</th>
                                            <th>Customer Email</th>
                                            <th class="text-center">Customer Phone</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($index + 1); ?></td>
                                                <td>
                                                    <?php echo e($customer->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($customer->email); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($customer->phone); ?>

                                                </td>
                                                <td class="text-center">
                                                    <button class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#viewCustomerModal<?php echo e($customer->id); ?>">
                                                        <i class="fa-solid fa-eye"></i> View
                                                    </button>
                                                </td>
                                            </tr>

                                            <div class="modal fade" id="viewCustomerModal<?php echo e($customer->id); ?>"
                                                tabindex="-1" aria-labelledby="viewCustomerModalLabel<?php echo e($customer->id); ?>"
                                                aria-hidden="true">
                                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="viewCustomerModalLabel<?php echo e($customer->id); ?>">
                                                                Customer Details
                                                            </h5>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <h4 class="mb-3">Customer Details</h4>
                                                                    <p><strong>Customer Name:</strong>
                                                                        <?php echo e($customer->name); ?>

                                                                    </p>
                                                                    <p><strong>Customer Email:</strong>
                                                                        <?php echo e($customer->email); ?></p>
                                                                    <p><strong>Customer Phone:</strong>
                                                                        <?php echo e($customer->phone); ?></p>
                                                                </div>
                                                                <hr>
                                                                <div class="col-md-12">
                                                                    <h4 class="mb-3">Customer Address</h4>
                                                                    <?php $__currentLoopData = $customer->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <p><strong>Address <?php echo e($index + 1); ?>:</strong>
                                                                            <?php echo e($address->name); ?> - <?php echo e($address->phone); ?>

                                                                            <br>
                                                                            <?php echo e($address->address); ?>,
                                                                            <?php echo e($address->ward_name); ?>,
                                                                            <?php echo e($address->district_name); ?>,
                                                                            <?php echo e($address->city_name); ?>.
                                                                        </p>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                                <hr>
                                                                <div class="col-md-12">
                                                                    <h4 class="mb-3">Customer Orders</h4>
                                                                    <ul>
                                                                        <?php $__currentLoopData = $customer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li>
                                                                                <strong>Order
                                                                                    <?php echo e($order->order_code); ?>:</strong>
                                                                                <?php echo e($order->created_at->format('d-m-Y')); ?> -
                                                                                <strong>Order Status:</strong>
                                                                                <?php echo e(ucfirst($order->status)); ?> -
                                                                                <strong>Order Total:</strong>
                                                                                $<?php echo e($order->total_price); ?>

                                                                                <hr>
                                                                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <p><strong>Product
                                                                                            Name:</strong>
                                                                                        <?php echo e($order_item->product->name); ?>

                                                                                        ($<?php echo e(number_format($order_item->productVariant->price, 0, ',', '.')); ?>)
                                                                                        /
                                                                                        <?php echo e($order_item->productVariant->name); ?>

                                                                                        x <?php echo e($order_item->quantity); ?> =
                                                                                        <?php echo e(number_format($order_item->productVariant->price * $order_item->quantity, 0, ',', '.')); ?>


                                                                                    </p>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/customers/index.blade.php ENDPATH**/ ?>