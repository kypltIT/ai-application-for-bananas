<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <div class="content">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <!-- Dashboard Statistics -->
            <div class="row">
                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="card dash-widget shadow-sm">
                        <div class="card-body text-center">
                            <div class="dash-widget-header">
                                <div class="dash-content">
                                    <i class="fas fa-box fa-2x mb-2"></i>
                                    <h4 class="font-weight-bold text-uppercase">Total Products</h4>
                                    <h2 style="color: #2E37A4;"><?php echo e($totalProducts); ?></h2>
                                    <p class="text-muted">Number of Products Available</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="card dash-widget shadow-sm">
                        <div class="card-body text-center">
                            <div class="dash-widget-header">
                                <div class="dash-content">
                                    <i class="fas fa-shopping-cart fa-2x mb-2"></i>
                                    <h4 class="font-weight-bold text-uppercase">Total Orders</h4>
                                    <h2 style="color: #2E37A4;"><?php echo e($totalOrders); ?></h2>
                                    <p class="text-muted">Number of Orders Processed</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="card dash-widget shadow-sm">
                        <div class="card-body text-center">
                            <div class="dash-widget-header">
                                <div class="dash-content">
                                    <i class="fas fa-users fa-2x mb-2"></i>
                                    <h4 class="font-weight-bold text-uppercase">Total Customers</h4>
                                    <h2 style="color: #2E37A4;"><?php echo e($totalCustomers); ?></h2>
                                    <p class="text-muted">Number of Registered Customers</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="card dash-widget shadow-sm">
                        <div class="card-body text-center">
                            <div class="dash-widget-header">
                                <div class="dash-content">
                                    <i class="fas fa-dollar-sign fa-2x mb-2"></i>
                                    <h4 class="font-weight-bold text-uppercase">Total Revenue</h4>
                                    <h2 style="color: #2E37A4;">$<?php echo e(number_format($totalRevenue, 2, '.', ',')); ?></h2>
                                    <p class="text-muted">Total Revenue Generated</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Monthly Sales Chart -->
                <div class="col-md-7">
                    <div class="card card-chart">
                        <div class="card-header">
                            <h4 class="card-title">Monthly Sales</h4>
                        </div>
                        <div class="card-body">
                            <div id="sales-chart"></div>
                        </div>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Quick Stats</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="stats-info">
                                        <h6>Blog Posts</h6>
                                        <h4><?php echo e($totalBlogs); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="stats-info">
                                        <h6>Unread Messages</h6>
                                        <h4><?php echo e($unreadContacts); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Blog Posts -->
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Recent Blog Posts</h4>
                        </div>
                        <div class="card-body">
                            <ul class="activity-feed">
                                <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="feed-item">
                                        <div class="feed-date"><?php echo e($blog->created_at->format('M d')); ?></div>
                                        <span class="feed-text">
                                            <strong><?php echo e(Str::limit($blog->title, 30)); ?></strong>
                                            <span class="badge bg-info"><?php echo e($blog->blogCategory->name); ?></span>
                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Location-based Sales Charts -->
            <div class="row">
                <!-- City Sales Chart -->
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header">
                            <h4 class="card-title">Top Cities by Sales</h4>
                        </div>
                        <div class="card-body">
                            <div id="city-sales-chart"></div>
                        </div>
                    </div>
                </div>

                <!-- District Sales Chart -->
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header">
                            <h4 class="card-title">Top Districts by Sales</h4>
                        </div>
                        <div class="card-body">
                            <div id="district-sales-chart"></div>
                        </div>
                    </div>
                </div>

                <!-- Ward Sales Chart -->
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header">
                            <h4 class="card-title">Top Wards by Sales</h4>
                        </div>
                        <div class="card-body">
                            <div id="ward-sales-chart"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Recent Orders -->
                <div class="col-md-8">
                    <div class="card card-table">
                        <div class="card-header">
                            <h4 class="card-title">Recent Orders</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border-0  datatable1 mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Customer</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><a
                                                        href="<?php echo e(route('admin.orders.show', $order->id)); ?>"><?php echo e($order->order_code); ?></a>
                                                </td>
                                                <td><?php echo e($order->customer->name); ?></td>
                                                <td>$<?php echo e(number_format($order->total_price, 2, '.', ',')); ?></td>
                                                <td>
                                                    <?php if($order->status == 'completed'): ?>
                                                        <span class="badge bg-success">Completed</span>
                                                    <?php elseif($order->status == 'processing'): ?>
                                                        <span class="badge bg-warning">Processing</span>
                                                    <?php elseif($order->status == 'ordered'): ?>
                                                        <span class="badge bg-info">Ordered</span>
                                                    <?php elseif($order->status == 'cancelled'): ?>
                                                        <span class="badge bg-danger">Cancelled</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="text-center">No orders found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Customers -->
                <div class="col-md-4">
                    <div class="card card-table">
                        <div class="card-header">
                            <h4 class="card-title">Recent Customers</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border-0 datatable1 mb-0 ">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $recentCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('admin.customers.show', $customer->id)); ?>">
                                                        <?php echo e($customer->name); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($customer->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="2" class="text-center">No customers found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {

        // Monthly sales chart
        var monthlySalesData = <?php echo json_encode($monthlySales, 15, 512) ?>;

        var months = monthlySalesData.map(item => item.month);
        var revenues = monthlySalesData.map(item => parseInt(item.revenue));

        var salesChartOptions = {
            series: [{
                name: 'Revenue',
                data: revenues
            }],
            chart: {
                height: 350,
                type: 'area',
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: true
            },
            stroke: {
                curve: 'smooth',
                width: 3,
            },
            colors: ['#2E37A4'],
            xaxis: {
                categories: months
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            },
            fill: {
                opacity: 0.2
            }
        };

        var salesChart = new ApexCharts(document.querySelector("#sales-chart"), salesChartOptions);
        salesChart.render();

        // City sales chart
        var citySalesData = <?php echo json_encode($citySales, 15, 512) ?>;
        var cityNames = citySalesData.map(item => item.name);
        var cityRevenues = citySalesData.map(item => parseInt(item.revenue));

        var citySalesChartOptions = {
            series: [{
                name: 'Revenue',
                data: cityRevenues
            }],
            chart: {
                type: 'bar',
                height: 350,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true,
                }
            },
            dataLabels: {
                enabled: true
            },
            colors: ['#3b7ddd'],
            xaxis: {
                categories: cityNames,
                labels: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ' đ';
                    }
                }
            }
        };

        var citySalesChart = new ApexCharts(document.querySelector("#city-sales-chart"), citySalesChartOptions);
        citySalesChart.render();

        // District sales chart
        var districtSalesData = <?php echo json_encode($districtSales, 15, 512) ?>;
        var districtNames = districtSalesData.map(item => item.name);
        var districtRevenues = districtSalesData.map(item => parseInt(item.revenue));

        var districtSalesChartOptions = {
            series: [{
                name: 'Revenue',
                data: districtRevenues
            }],
            chart: {
                type: 'bar',
                height: 350,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true,
                }
            },
            dataLabels: {
                enabled: true
            },
            colors: ['#28a745'],
            xaxis: {
                categories: districtNames,
                labels: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            }
        };

        var districtSalesChart = new ApexCharts(document.querySelector("#district-sales-chart"),
            districtSalesChartOptions);
        districtSalesChart.render();

        // Ward sales chart
        var wardSalesData = <?php echo json_encode($wardSales, 15, 512) ?>;
        var wardNames = wardSalesData.map(item => item.name);
        var wardRevenues = wardSalesData.map(item => parseInt(item.revenue));

        var wardSalesChartOptions = {
            series: [{
                name: 'Revenue',
                data: wardRevenues
            }],
            chart: {
                type: 'bar',
                height: 350,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true,
                }
            },
            dataLabels: {
                enabled: true
            },
            colors: ['#fd7e14'],
            xaxis: {
                categories: wardNames,
                labels: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            },
            tooltip: {
                y: {
                    formatter: function(val) {
                        return '$' + val.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            }
        };

        var wardSalesChart = new ApexCharts(document.querySelector("#ward-sales-chart"), wardSalesChartOptions);
        wardSalesChart.render();
    });
</script>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>