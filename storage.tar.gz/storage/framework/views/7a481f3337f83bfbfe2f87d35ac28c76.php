<script src="<?php echo e(asset('assets/admin/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.slimscroll.js')); ?>"></script>


<script src="<?php echo e(asset('assets/admin/js/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/fileupload/fileupload.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('tinymce/tinymce.min.js')); ?>" referrerpolicy="origin"></script>
<?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/admin/appjs.blade.php ENDPATH**/ ?>