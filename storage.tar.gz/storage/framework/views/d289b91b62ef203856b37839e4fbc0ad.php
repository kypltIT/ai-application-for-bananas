<?php $__env->startSection('title', 'Order List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.orders.index')); ?>">Order Management </a>
                            </li>
                            <li class="breadcrumb-item"><i class="feather-chevron-right"></i></li>
                            <li class="breadcrumb-item active">Order List</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="card card-table show-entire">
                        <div class="card-body">

                            <!-- Table Header -->
                            <div class="page-table-header mb-2">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="doctor-table-blk">
                                            <h3>Order List</h3>
                                            <div class="doctor-search-blk">
                                                <div class="top-nav-search table-search-blk">
                                                    <form>
                                                        <input type="text" class="form-control"
                                                            placeholder="Search here">
                                                        <a class="btn"><img
                                                                src="<?php echo e(asset('assets/admin/img/icons/search-normal.svg')); ?>"
                                                                alt=""></a>
                                                    </form>
                                                </div>
                                                <div class="add-group">
                                                    <button class="btn btn-primary add-pluss ms-2" data-bs-toggle="modal"
                                                        data-bs-target="#add_product"><img
                                                            src="<?php echo e(asset('assets/admin/img/icons/plus.svg')); ?>"
                                                            alt=""></button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto text-end float-end ms-auto download-grp">
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-01.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-02.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-03.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-04.svg')); ?>"
                                                alt=""></a>

                                    </div>
                                </div>
                            </div>
                            <!-- /Table Header -->

                            <div class="table-responsive">
                                <table class="table border-0 custom-table comman-table datatable mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order Code</th>
                                            <th>Customer</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Order Note</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="profile-image"><?php echo e($order->order_code); ?></td>
                                                <td>
                                                    <?php echo e($order->customer->name); ?>

                                                </td>
                                                <td>
                                                    $<?php echo e(number_format($order->total_price, 0)); ?>

                                                </td>
                                                <td>
                                                    <span
                                                        class="badge
                                                        <?php if($order->status == 'ordered'): ?> bg-info
                                                        <?php elseif($order->status == 'processing'): ?> bg-warning
                                                        <?php elseif($order->status == 'completed'): ?> bg-success
                                                        <?php elseif($order->status == 'cancelled'): ?> bg-danger <?php endif; ?>
                                                    ">
                                                        <?php echo e(ucfirst($order->status)); ?>

                                                    </span>
                                                </td>
                                                <td style="white-space: nowrap;">
                                                    <?php echo e($order->order_note); ?>

                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                                        class="btn btn-warning add-pluss ms-2">
                                                        <i class="fa-solid fa-eye"></i> View
                                                    </a>

                                                </td>
                                            </tr>

                                            <!-- Edit Modal -->


                                            <!-- Delete Modal -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>