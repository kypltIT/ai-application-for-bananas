<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('storage/' . getSetting('site_favicon'))); ?>">
<title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(getSetting('site_name')); ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="description" content="<?php echo e(getSetting('site_description')); ?>">
<meta name="keywords" content="<?php echo e(getSetting('site_keywords')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/fontawesome/css/all.min.css')); ?>">
<!-- Feathericon CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/feather.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/datatables/datatables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/select2.min.css')); ?>">
<?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/admin/appcss.blade.php ENDPATH**/ ?>