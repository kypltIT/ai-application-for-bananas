<?php $__env->startSection('title', 'General Settings'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard </a></li>
                            <li class="breadcrumb-item"><i class="feather-chevron-right"></i></li>
                            <li class="breadcrumb-item active">Settings</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            

            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow-sm">
                        <div class="card-body ">
                            <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="settings-form">

                                    
                                    <div class="input-block mb-3">
                                        <label class="font-weight-bold">Website Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Website Name"
                                            name="site_name" value="<?php echo e($settings['site_name'] ?? ''); ?>">
                                    </div>

                                    
                                    <div class="input-block mb-3">
                                        <label class="font-weight-bold">Website Description</label>
                                        <textarea class="form-control" name="site_description" rows="3" placeholder="Enter description..."><?php echo e($settings['site_description'] ?? ''); ?></textarea>
                                    </div>

                                    
                                    <div class="input-block mb-3">
                                        <label class="font-weight-bold">SEO Keywords</label>
                                        <input type="text" class="form-control" placeholder="Enter keywords"
                                            name="site_keywords" value="<?php echo e($settings['site_keywords'] ?? ''); ?>">
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            
                                            <div class="input-block mb-3">
                                                <p class="settings-label font-weight-bold">Logo</p>
                                                <div class="settings-btn">
                                                    <input type="file" accept="image/*" name="site_logo"
                                                        onchange="loadFile(event)" class="hide-input">
                                                    <label for="site_logo" class="upload btn btn-outline-secondary">
                                                        <i class="feather-upload"></i>
                                                    </label>
                                                </div>

                                                <?php if(!empty($settings['site_logo'])): ?>
                                                    <div class="upload-images">
                                                        <img src="<?php echo e(asset('storage/' . $settings['site_logo'])); ?>"
                                                            alt="Logo" class="img-thumbnail" style="max-width: 150px;">
                                                        <a href="javascript:void(0);" class="btn-icon logo-hide-btn">
                                                            <i class="feather-x-circle"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            
                                            <div class="input-block mb-3">
                                                <p class="settings-label font-weight-bold">Favicon</p>
                                                <div class="settings-btn">
                                                    <input type="file" accept="image/*" name="site_favicon"
                                                        onchange="loadFile(event)" class="hide-input">
                                                    <label for="site_favicon" class="upload btn btn-outline-secondary">
                                                        <i class="feather-upload"></i>
                                                    </label>
                                                </div>
                                                <?php if(!empty($settings['site_favicon'])): ?>
                                                    <div class="upload-images upload-size">
                                                        <img src="<?php echo e(asset('storage/' . $settings['site_favicon'])); ?>"
                                                            alt="Favicon" class="img-thumbnail" style="max-width: 50px;">
                                                        <a href="javascript:void(0);" class="btn-icon logo-hide-btn">
                                                            <i class="feather-x-circle"></i>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            
                                            <div class="input-block mb-3">
                                                <label class="font-weight-bold">Email</label>
                                                <input type="email" class="form-control" name="site_email"
                                                    value="<?php echo e($settings['site_email'] ?? ''); ?>"
                                                    placeholder="Enter site email">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            
                                            <div class="input-block mb-3">
                                                <label class="font-weight-bold">Phone Number</label>
                                                <input type="text" class="form-control" name="site_phone"
                                                    value="<?php echo e($settings['site_phone'] ?? ''); ?>"
                                                    placeholder="Enter phone number">
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="input-block mb-3">
                                        <label class="font-weight-bold">Address</label>
                                        <input type="text" class="form-control" name="site_address"
                                            value="<?php echo e($settings['site_address'] ?? ''); ?>" placeholder="Enter address">
                                    </div>

                                    <div class="row">
                                        <?php $__currentLoopData = ['facebook', 'instagram', 'tiktok', 'youtube']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <div class="input-block mb-3">
                                                    <label class="font-weight-bold"><?php echo e(ucfirst($social)); ?> URL</label>
                                                    <input type="text" class="form-control"
                                                        name="site_<?php echo e($social); ?>"
                                                        value="<?php echo e($settings['site_' . $social] ?? ''); ?>"
                                                        placeholder="https://<?php echo e($social); ?>.com/yourprofile">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <hr>

                                    
                                    <?php $__currentLoopData = ['sub', 'main', 'description']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="input-block mb-3">
                                            <p class="settings-label font-weight-bold"><?php echo e(ucfirst($intro)); ?> Introduction
                                            </p>
                                            <input type="text" class="form-control"
                                                name="<?php echo e($intro); ?>_introduction"
                                                placeholder="Enter <?php echo e($intro); ?> introduction..."
                                                value="<?php echo e($settings[$intro . '_introduction'] ?? ''); ?>">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                    <div class="input-block mb-3">
                                        <p class="settings-label font-weight-bold">Image Introduction (460px x 550px)</p>
                                        <div class="settings-btn">
                                            <input type="file" accept="image/*" name="image_introduction"
                                                onchange="loadFile(event)" class="hide-input">
                                            <label for="image_introduction" class="upload btn btn-outline-secondary">
                                                <i class="feather-upload"></i>
                                            </label>
                                        </div>

                                        <?php if(!empty($settings['image_introduction'])): ?>
                                            <div class="upload-images upload-size">
                                                <img src="<?php echo e(asset('storage/' . $settings['image_introduction'])); ?>"
                                                    alt="Image Introduction" class="img-thumbnail"
                                                    style="max-width: 150px;">
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    
                                    <div class="input-block mb-0">
                                        <div class="settings-btns">
                                            <button type="submit"
                                                class="btn btn-primary btn-gradient-primary btn-rounded">Update</button>
                                            <a href="<?php echo e(url()->previous()); ?>"
                                                class="btn btn-secondary btn-rounded">Cancel</a>
                                        </div>
                                    </div>

                                </div>
                            </form>


                        </div>
                    </div>
                </div>

            </div>

        </div>
        <!-- /Page Content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/settings/index.blade.php ENDPATH**/ ?>