<?php $__env->startSection('title', 'Fashion Trend Analysis'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Fashion Trend Analysis</h1>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">Analyze Current Fashion Trends</h6>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.trend-analysis.analyze')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="fashion_trend">Describe Current Fashion Trends</label>
                                        <textarea class="form-control" id="fashion_trend" name="fashion_trend" rows="3"
                                            placeholder="E.g., Sustainable fashion is gaining popularity with eco-friendly materials and minimalist designs becoming mainstream..."
                                            required><?php echo e(old('fashion_trend')); ?></textarea>
                                        <small class="form-text text-muted">Describe current fashion trends that you want to
                                            analyze
                                            for your business strategy</small>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Analyze Trend Impact</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Historical Sales Data (Last 12 Months)</h6>
                            </div>
                            <div class="card-body">
                                <div class="chart-area">
                                    <canvas id="monthlySalesChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Product Category Performance</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Category</th>
                                                <th>Products</th>
                                                <th>Units Sold</th>
                                                <th>Revenue</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categoryPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($category->name); ?></td>
                                                    <td><?php echo e($category->product_count); ?></td>
                                                    <td><?php echo e($category->units_sold); ?></td>
                                                    <td>$<?php echo e(number_format($category->revenue, 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Chart for monthly sales
            const salesCtx = document.getElementById('monthlySalesChart').getContext('2d');

            const salesData = <?php echo json_encode($monthlySales, 15, 512) ?>;

            // Debug: Check if data is available
            console.log('Monthly Sales Data:', salesData);

            if (salesData && salesData.length > 0) {
                const monthlySalesChart = new Chart(salesCtx, {
                    type: 'line',
                    data: {
                        labels: salesData.map(item => item.month),
                        datasets: [{
                            label: 'Monthly Revenue',
                            data: salesData.map(item => item.revenue),
                            backgroundColor: 'rgba(78, 115, 223, 0.05)',
                            borderColor: 'rgba(78, 115, 223, 1)',
                            pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
                            borderWidth: 2,
                            fill: true
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: false,
                                ticks: {
                                    callback: function(value) {
                                        return '$' + value.toLocaleString();
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Revenue: $' + context.parsed.y.toLocaleString();
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                // If no data, display a message
                document.querySelector('.chart-area').innerHTML =
                    '<div class="text-center p-4">No sales data available for the selected period.</div>';
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/trend-analysis/index.blade.php ENDPATH**/ ?>