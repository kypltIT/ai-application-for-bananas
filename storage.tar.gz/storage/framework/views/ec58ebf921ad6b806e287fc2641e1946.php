<div class="icon">
    <i class="fas fa-shopping-bag"></i><span class="pro-count"
        style="background-color: #ffffff;"><?php echo e(countCartItems()); ?></span>
</div>
<?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/guest/components/count-cart-items.blade.php ENDPATH**/ ?>