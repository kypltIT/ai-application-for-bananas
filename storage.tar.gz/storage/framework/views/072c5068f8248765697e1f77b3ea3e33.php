<?php $__currentLoopData = getCartItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="sidebar-cart-item">
        <a style="cursor: pointer;" id="remove-cart" data-cart-id="<?php echo e($cartItem->id); ?>" class="remove-cart"><i
                class="far fa-trash-alt"></i></a>
        <a href="#">
            <img src="<?php echo e(asset('storage/' . $cartItem->product->productVariants()->first()->productVariantImages()->first()->image_path)); ?>"
                alt="cart image">
            <?php echo e($cartItem->product->name); ?>

        </a>
        <span><?php echo e($cartItem->productVariant->name); ?></span> <br>
        <span class="quantity"><?php echo e($cartItem->quantity); ?> × <span><span
                    class="currency">$</span><?php echo e(number_format($cartItem->productVariant->price, 0)); ?></span></span>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="text-center alert alert-danger" id="empty-cart-message" style="display: none;">
    <p>Your cart is empty.</p>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var removeCartButtons = document.querySelectorAll('.remove-cart');
        removeCartButtons.forEach(function(button) {
            button.addEventListener('click', function(event) {
                event.preventDefault();
                var cartId = this.getAttribute('data-cart-id');
                var listItem = this.closest('.sidebar-cart-item');

                var xhr = new XMLHttpRequest();
                xhr.open('POST', "<?php echo e(route('cart.removeFromCart')); ?>", true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                                // Xóa phần tử <li> khỏi DOM
                            listItem.remove();
                            // Kiểm tra nếu giỏ hàng trống
                            if (document.querySelectorAll('.sidebar-cart-item').length ===
                                0) {
                                document.getElementById('empty-cart-message').style
                                    .display = 'block';
                                document.getElementById('cart-total-price').style
                                    .display = 'none';
                            }
                        } else {
                            console.error('Xóa giỏ hàng thất bại');
                        }
                    }
                };
                xhr.send('cart_item_id=' + encodeURIComponent(cartId));
            });
        });
    });
</script>
<?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/guest/components/cart-items.blade.php ENDPATH**/ ?>