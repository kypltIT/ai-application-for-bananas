<?php $__env->startSection('title', 'Blog List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.blog-categories.index')); ?>">Blog
                                    Management </a></li>
                            <li class="breadcrumb-item"><i class="feather-chevron-right"></i></li>
                            <li class="breadcrumb-item active">Blog List</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="card card-table show-entire">
                        <div class="card-body">

                            <!-- Table Header -->
                            <div class="page-table-header mb-2">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="doctor-table-blk">
                                            <h3>Blog List</h3>
                                            <div class="doctor-search-blk">
                                                <div class="top-nav-search table-search-blk">
                                                    <form>
                                                        <input type="text" class="form-control"
                                                            placeholder="Search here">
                                                        <a class="btn"><img
                                                                src="<?php echo e(asset('assets/admin/img/icons/search-normal.svg')); ?>"
                                                                alt=""></a>
                                                    </form>
                                                </div>
                                                <div class="add-group">
                                                    <button class="btn btn-primary add-pluss ms-2" data-bs-toggle="modal"
                                                        data-bs-target="#add_blog"><img
                                                            src="<?php echo e(asset('assets/admin/img/icons/plus.svg')); ?>"
                                                            alt=""></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto text-end float-end ms-auto download-grp">
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-01.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-02.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;" class=" me-2"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-03.svg')); ?>"
                                                alt=""></a>
                                        <a href="javascript:;"><img
                                                src="<?php echo e(asset('assets/admin/img/icons/pdf-icon-04.svg')); ?>"
                                                alt=""></a>

                                    </div>
                                </div>
                            </div>
                            <!-- /Table Header -->

                            <div class="table-responsive">
                                <table class="table border-0 custom-table comman-table datatable mb-0">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Slug</th>
                                            <th>Category</th>
                                            <th>Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="profile-image"><?php echo e($blog->title); ?></td>
                                                <td class="text-wrap"><?php echo e($blog->slug); ?></td>
                                                <td class="text-wrap"><?php echo e($blog->blogCategory->name); ?></td>
                                                <td>
                                                    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="Blog Image"
                                                        class="img-fluid" style="width: 100px; height: 100px;">
                                                </td>
                                                <td>
                                                    <button class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#edit_blog_<?php echo e($blog->id); ?>">
                                                        <i class="fa-solid fa-pen-to-square m-r-5"></i> Edit
                                                    </button>
                                                    <button class="btn btn-danger" data-bs-toggle="modal"
                                                        data-bs-target="#delete_blog_<?php echo e($blog->id); ?>">
                                                        <i class="fa fa-trash-alt m-r-5"></i> Delete
                                                    </button>
                                                </td>
                                            </tr>

                                            <!-- Edit Modal -->
                                            <div class="modal fade" id="edit_blog_<?php echo e($blog->id); ?>" tabindex="-1"
                                                aria-labelledby="editBlogLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editBlogLabel">Edit
                                                                Blog</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <form action="<?php echo e(route('admin.blogs.update', $blog->id)); ?>"
                                                            method="POST" enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="modal-body">

                                                                <div class="mb-3">
                                                                    <label for="title" class="form-label">Title</label>
                                                                    <input type="text" class="form-control"
                                                                        id="title" name="title"
                                                                        value="<?php echo e($blog->title); ?>" required>
                                                                </div>

                                                                <div class="mb-3">
                                                                    <label for="blog_category_id"
                                                                        class="form-label">Category</label>
                                                                    <select class="form-select" id="blog_category_id"
                                                                        name="blog_category_id" required>
                                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($category->id); ?>"
                                                                                <?php echo e($blog->blog_category_id == $category->id ? 'selected' : ''); ?>>
                                                                                <?php echo e($category->name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                                <div class="mb-3">
                                                                    <label for="image" class="form-label">Image (342px x
                                                                        223px)</label>
                                                                    <input type="file" class="form-control"
                                                                        id="image" name="image"
                                                                        <?php if(!$blog->image): ?> required <?php endif; ?>>
                                                                </div>

                                                                <?php if($blog->image): ?>
                                                                    <div class="mb-3">
                                                                        <img src="<?php echo e(asset('storage/' . $blog->image)); ?>"
                                                                            alt="Blog Image" class="img-fluid"
                                                                            style="height: 100px;">
                                                                    </div>
                                                                <?php endif; ?>


                                                                <div class="mb-3">
                                                                    <label for="content"
                                                                        class="form-label">Content</label>
                                                                    <textarea class="form-control" id="content_<?php echo e($blog->id); ?>" name="content" rows="5"><?php echo e($blog->content); ?></textarea>
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Update
                                                                    Blog</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="delete_blog_<?php echo e($blog->id); ?>" tabindex="-1"
                                                aria-labelledby="deleteBlogLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="deleteBlogLabel">
                                                                Delete
                                                                Blog</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Are you sure you want to delete this blog?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Cancel</button>
                                                                <button type="submit" class="btn btn-danger">Delete
                                                                    Blog</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Add New Product Category Modal -->
                            <div class="modal fade" id="add_blog" tabindex="-1" aria-labelledby="addBlogLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="addBlogLabel">Add New Blog
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('admin.blogs.store')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">

                                                <div class="mb-3">
                                                    <label for="title" class="form-label">Title</label>
                                                    <input type="text" class="form-control" id="title"
                                                        name="title" required>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="blog_category_id" class="form-label">Category</label>
                                                    <select class="form-select" id="blog_category_id"
                                                        name="blog_category_id" required>
                                                        <option value="">Select Category</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="image" class="form-label">Image (342px x
                                                        223px)</label>
                                                    <input type="file" class="form-control" id="image"
                                                        name="image" required>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="content" class="form-label">Content</label>
                                                    <textarea class="form-control" id="content" name="content" rows="5"></textarea>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Add New Blog
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            tinymce.init({
                selector: '#content',
                plugins: 'lists',
                toolbar: 'lists',
                license_key: 'gpl',
            });

        });

        $(document).ready(function() {
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                tinymce.init({
                    selector: '#content_<?php echo e($blog->id); ?>',
                    plugins: 'lists',
                    toolbar: 'lists',
                    license_key: 'gpl',
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/admin/blogs/index.blade.php ENDPATH**/ ?>