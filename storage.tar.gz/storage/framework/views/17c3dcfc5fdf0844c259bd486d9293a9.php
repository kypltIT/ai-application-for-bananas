<?php if(getCartItems()->count() > 0): ?>
    <div class="cart-mini-total">
        <div class="cart-total">
            <span><strong>Subtotal:</strong></span> <span class="amount"> <span><span
                        class="currency">$</span><?php echo e(number_format(getCartTotal(), 0)); ?></span></span>
        </div>
    </div>

    <div class="cart-button-box">
        <a href="<?php echo e(route('orders.index')); ?>" class="theme-btn style-one">Proceed to
            checkout</a>
    </div>
<?php else: ?>
    <div class="cart-mini-total">
        <div class="cart-total">
            <div class="text-center">
                <p>Your cart is empty</p>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/guest/components/cart-total-price.blade.php ENDPATH**/ ?>