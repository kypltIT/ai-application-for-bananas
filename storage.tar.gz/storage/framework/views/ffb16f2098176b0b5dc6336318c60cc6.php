<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.admin.appcss', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <div class="main-wrapper">

        <?php echo $__env->make('layouts.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('layouts.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    
    <div class="sidebar-overlay" data-reff=""></div>

    <?php echo $__env->make('layouts.admin.appjs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH /www/wwwroot/biha.techzone.edu.vn/resources/views/layouts/admin/app.blade.php ENDPATH**/ ?>